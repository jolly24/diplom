<?php

/** @var yii\web\View $this */

$this->title = 'Магазин музыкальных инструментов';
?>
<div class="site-index">

</div>
