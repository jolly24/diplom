<?php

/** @var yii\web\View $this */
use yii\helpers\Url;
$this->title = 'категории';
?>
<div class="cart_img">
    <div class="img_prod">
        <img src="img/1.jpeg">

    </div>
    <div class="content_cart">
        <h1>sss></h1>
        <p><span>Артикул:</span></p>

        <?php

        ?>
            <p>В наличии <strong class="count_prod"></strong></p>
        <?php
        ?>
                <p>Нет в наличии</p>
        <?php
        ?>
        <p><</p>
    </div>  
    <div class="col-lg-3 col-md-8 col-sm-7 col-sm-offset--5 col-xs-12">
    <div class="order_prod">
        <p class="price_prod">123руб</p>

        <?php
            if(!empty($product_array['price_old'])):
        ?>
            <p class="price_old_prod">123руб</p>
        <?php
            endif;
        ?>

  
        <p>Количество:</p>
        <form class="form_count_prod">
            <input type="text" name="" value="1" class="input_text">
            <button type="button" class="minus">-</button>
            <button type="button" class="plus">+</button>
        </form>
    
            <p>Нет в наличии</p>
      
        <a href="#" class="add_mylist_prod "><i class="glyphicon  fa fa-heart"></i>В корзину</a>
    </div>
    </div>
</div>
          

   













<div class="site-index">

</select>
   <!-- <p><input type="submit" value="Отправить"></p> -->
  </form>
  <!-- <div class="wrapper mt-5">
    <div class="container">
        <div class="roww">

    
        

        <div class="row">
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
            </nav>
        </div><!-- /row -->

    <!-- </div>/container --> -->
</div><!-- /wrapper -->
</div>

         
