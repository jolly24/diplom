<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class PageController extends Controller
{
///контролер для страниц сайта


    public function actionListproduct() ///главная страница
    {
        return $this->render('listproduct');
    }

    public function actionContacts() ///где нас найти
    {
        return $this->render('contacts');
    }


}
