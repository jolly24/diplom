<?php

/** @var yii\web\View $this */

$this->title = 'Магазин музыкальных инструментов';
?>
<div class="site-index">
<form action="select1.php" method="post">
   <p><select name="categorii">
  <optgroup label="Год">
    <option value="1">2023</option>
    <option value="2">2022</option>
    <option value="3">2021</option>
  </optgroup>
 
</select>
   <p><input type="submit" value="Отправить"></p>
  </form>
  <form action="select1.php" method="post">
   <p><select name="categorii">
  <optgroup label="по наименованию">
    <option value="1">Москва</option>
    <option value="2">Санкт-Петербург</option>
    <option value="3">Новосибирск</option>
  </optgroup>
  
</select>
   <p><input type="submit" value="Отправить"></p>
  </form>
  <form action="select1.php" method="post">
   <p><select name="categorii">
  <optgroup label="цене">
    <option value="1">С большего к меньшему</option>
    <option value="2">С меньшего к большему</option>
    <option value="3"></option>
  </optgroup>

</select>
   <p><input type="submit" value="Отправить"></p>
  </form>
  </form>
  <form action="select1.php" method="post">
   <p><select name="categorii">
  <optgroup label="категории">
    <option value="1">струнные</option>
    <option value="2">клавишные </option>
    <option value="3">смычковые</option>
  </optgroup>

</select>
   <p><input type="submit" value="Отправить"></p>
  </form>
<div class="wrapper mt-5">
    <div class="container">
        <div class="row">

            <div class="product-cards mb-5">
            <?php  ?>
                <?php if(!empty($productss)): ?> <!-- Проверяет есть ли продукт  -->
                <?php foreach ($products as $product): ?> <!-- цикл по выводу подуктов  -->
                <div class="product-card">
                    <div class="offer">
                        <?php if($productss ['hit']): ?> <!-- вывод иконки хит  -->
                        <div class="offer-hit">Hit</div>
                        <?php endif; ?>
                        <?php if($productss ['sale']): ?> <!-- вывод иконки распродажа  -->
                        <div class="offer-sale">Sale</div>
                        <?php endif; ?>
                    </div>
                    <div class="card-thumb">

                    <a href="tovar/1.php?slug=<?=$productss['slug']?>"><img src="img/1<?= $productss['img'] ?>" alt="<?= $productss['title'] ?>"></a><!-- вывод картинки  -->
                    </div>
                    <div class="card-caption">
                        <div class="card-title">
                        <a href="#"><?= $productss['title'] ?></a><!-- вывод Название товара  -->
                        </div>
                        <div class="card-price text-center">
                        <?php if ($productss['old_price']): ?> <!-- Если есть старая цена то выводим саму цену в теге del  -->
                                        <del><?= $product['old_price'] ?> руб.</del><!-- вывод старой цены  -->
                                    <?php endif; ?>
                                    <?= $productss['price'] ?> руб. <!-- вывод цены  -->
                        </div>
                       
                        <a href="?cart=add&id=<?= $productss['id'] ?>" class="btn btn-info btn-block add-to-cart" data-id="<?= $productss['id'] ?>">
                                    <i class="fas fa-cart-arrow-down"></i> Купить
                                </a>
                        <div class="item-status"><i class="fas fa-check text-success"></i> В наличии</div>
                    </div>
                </div><!-- /product-card -->
                <?php endforeach; ?>     <!-- цикл по выводу подуктов  -->
                <?php endif; ?> <!-- Проверяет есть ли продукт  -->
                

            </div><!-- /product-cards -->
            <div class="product-cards mb-5">
            <?php  ?>
                 <!-- Проверяет есть ли продукт  -->
                 <!-- цикл по выводу подуктов  -->
                <div class="product-card">
                    <div class="offer">
                      
                    </div>
                    <div class="card-thumb">

                    <a href="tovar/1.php?slug="><img src="img/1.jpg" alt=" ?>"></a><!-- вывод картинки  -->
                    </div>
                    <div class="card-caption">
                        <div class="card-title">
                        <a href="#">gavno</a><!-- вывод Название товара  -->
                        </div>
                        <div class="card-price text-center">
                         <!-- Если есть старая цена то выводим саму цену в теге del  -->
                                        <del>50 руб.</del><!-- вывод старой цены  -->
                                    
                                    30 руб. <!-- вывод цены  -->
                        </div>
                       
                        <a href="?cart=add&id=" class="btn btn-info btn-block add-to-cart" data-id="">
                                    <i class="fas fa fa-cart-arrow-down"></i> Купить
                                </a>
                        <div class="item-status"><i class="fas fa fa-check text-success"></i> В наличии</div>
                    </div>
                </div><!-- /product-card -->
                
                

            </div><!-- /product-cards -->
        </div><!-- /row -->

        <div class="row">
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
            </nav>
        </div><!-- /row -->

    </div><!-- /container -->
</div><!-- /wrapper -->
</div>
