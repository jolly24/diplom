gavno
<div class="wrapper mt-5">
    <div class="container">
        <div class="row">
<h2>Наши адресса</h2>
<ul>
<li>+ 88 005 55 35 35</li>
<li>+ 88 005 55 35 35</li>
<li>+ 88 005 55 35 35</li>
<li>+ 88 005 55 35 35</li>
</ul>

        </div><!-- /row -->

        
    </div><!-- /container -->
</div><!-- /wrapper -->

<section class="infoslider">
<img src="img/map.jpg" alt="">
</section>